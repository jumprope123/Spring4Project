create definer = playground@`%` view 제품3 as
select `playground`.`sales_products`.`prdname`  AS `prdname`,
       `playground`.`sales_products`.`stock`    AS `stock`,
       `playground`.`sales_products`.`prdmaker` AS `prdmaker`
from `playground`.`sales_products`;

