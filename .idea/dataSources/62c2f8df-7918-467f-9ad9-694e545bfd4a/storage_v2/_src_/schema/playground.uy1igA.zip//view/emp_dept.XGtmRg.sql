create definer = playground@`%` view emp_dept as
(
select `e`.`employee_id`     AS `employee_id`,
       `e`.`last_name`       AS `last_name`,
       `e`.`first_name`      AS `first_name`,
       `d`.`department_id`   AS `department_id`,
       `d`.`department_name` AS `department_name`
from (`playground`.`departments` `d`
         join `playground`.`employees` `e` on (`d`.`department_id` = `e`.`department_id`)));

